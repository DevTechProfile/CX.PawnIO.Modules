# PawnIO IntelIMC Test Bundle

Self-contained dev bundle for running the IntelIMC PawnIO module on a fresh
Windows machine, including the unrestricted-build PawnIO driver, its
self-issued code-signing cert, the usermode runtime, and a pre-signed copy
of `IntelIMC.amx`.

## Contents

| Path | Purpose |
|---|---|
| `driver\PawnIO_unsigned.sys` | Self-built PawnIO driver with `PAWNIO_UNRESTRICTED=ON` and the local `string_buffer` off-by-one fix, signed by the bundled test cert. |
| `driver\PawnIO_TestCert.cer` | Public part of the self-issued code-signing cert. Installed into `LocalMachine\Root` + `TrustedPublisher` so the kernel accepts the driver's signature. |
| `runtime\PawnIOLib.dll` | Usermode loader / IOCTL shim. Exposes `pawnio_open` / `pawnio_load` / `pawnio_execute` / `pawnio_close`. |
| `runtime\PawnIOUtil.exe` | CLI for signing modules and smoke-testing loads. |
| `module\IntelIMC.signed.amx` | IntelIMC module already wrapped with a valid signature — the unrestricted driver accepts any signature, so no key is required on the target. |
| `test\Test-IntelIMC.ps1` | End-to-end IOCTL test — calls both the locked-max and live-workpoint IOCTLs and decodes the output. |
| `Install.ps1` / `Uninstall.ps1` | Bundle setup / teardown. |

## One-time target setup

Self-signed kernel drivers will not load unless Windows is in test signing
mode. From an elevated console:

```powershell
bcdedit /set testsigning on
Restart-Computer
```

After the reboot, also disable Memory Integrity / VBS / HVCI in
*Settings → Privacy & security → Windows Security → Device security →
Core isolation* if it is enabled — it blocks self-signed drivers regardless
of the testsigning flag.

## Install

```powershell
# from an elevated PowerShell, in this directory
.\Install.ps1
```

Idempotent. Re-running upgrades the driver image and refreshes trust.

## Run a test

```powershell
& 'C:\Program Files\PawnIO\PawnIOUtil.exe' test '.\module\IntelIMC.signed.amx'

# Full IOCTL run with decoded output:
.\test\Test-IntelIMC.ps1 `
    -AmxPath  (Resolve-Path .\module\IntelIMC.signed.amx).Path `
    -PawnIODir 'C:\Program Files\PawnIO'
```

## Notes for an Arrow Lake (PLAT_ARL) machine

The module's CPUID allowlist already covers ARL (CPUID model 0xC5 / 0xC6).
On first run you should see:

* Static IOCTL: `Source = MCHBAR_MEMSS_PMA`, `Flags = STATIC_LOCKED | EXPERIMENTAL`
* Live IOCTL: ratio that tracks memory activity, `Flags = LIVE_CURRENT | EXPERIMENTAL`

The `EXPERIMENTAL` flag stays set on ARL because `is_platform_validated` in
`IntelIMC.p` only returns true for PTL today. Once you have cross-checked
the locked-max value against HWiNFO's "Memory Clock" and confirmed the
live ratio tracks workpoint changes, you can extend the validated list and
rebuild the module.

## Uninstall

```powershell
.\Uninstall.ps1
Restart-Computer    # frees the loaded driver image; PawnIO has no DriverUnload
```

## Rebuilding from source

The `.amx` is signed with `my.key` (PKCS#8 RSA-2048 PEM) on the build host,
not bundled. Because the unrestricted driver accepts any signature, you do
*not* need that key on the target — the pre-signed `IntelIMC.signed.amx`
loads as-is. Bring the key only if you want to sign a fresh `.amx` on the
target after editing `IntelIMC.p`.
