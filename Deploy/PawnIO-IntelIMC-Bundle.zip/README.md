# PawnIO IntelIMC Test Bundle

Self-contained dev bundle for running the IntelIMC PawnIO module on a fresh
Windows machine, including the unrestricted-build PawnIO driver, its
self-issued code-signing cert, the usermode runtime, and a pre-signed copy
of `IntelIMC.amx`.

## Contents

| Path | Purpose |
|---|---|
| `driver\PawnIO_unsigned.sys` | Self-built PawnIO driver with `PAWNIO_UNRESTRICTED=ON` and the local `string_buffer` off-by-one fix, signed by the bundled test cert. |
| `driver\PawnIO_TestCert.cer` | Public part of the self-issued code-signing cert. Installed into `LocalMachine\Root` + `TrustedPublisher` so the kernel accepts the driver's signature. |
| `runtime\PawnIOLib.dll` | Usermode loader / IOCTL shim. Exposes `pawnio_open` / `pawnio_load` / `pawnio_execute` / `pawnio_close`. |
| `runtime\PawnIOUtil.exe` | CLI for signing modules and smoke-testing loads. |
| `module\IntelIMC.signed.amx` | IntelIMC module already wrapped with a valid signature -- the unrestricted driver accepts any signature, so no key is required on the target. |
| `test\Test-IntelIMC.ps1` | End-to-end IOCTL test -- calls both the locked-max and live-workpoint IOCTLs and decodes the output. |
| `Install.ps1` / `Uninstall.ps1` | Bundle setup / teardown. |

## One-time target setup

Self-signed kernel drivers will not load unless Windows is in test signing
mode. From an elevated console:

```powershell
bcdedit /set testsigning on
Restart-Computer
```

After the reboot, also disable Memory Integrity / VBS / HVCI in
*Settings -> Privacy & security -> Windows Security -> Device security ->
Core isolation* if it is enabled -- it blocks self-signed drivers regardless
of the testsigning flag.

## Install

```powershell
# from an elevated PowerShell, in this directory
.\Install.ps1
```

Idempotent. Re-running upgrades the driver image and refreshes trust.

## Run a test

```powershell
& 'C:\Program Files\PawnIO\PawnIOUtil.exe' test '.\module\IntelIMC.signed.amx'

# Full IOCTL run with decoded output:
.\test\Test-IntelIMC.ps1 `
    -AmxPath  (Resolve-Path .\module\IntelIMC.signed.amx).Path `
    -PawnIODir 'C:\Program Files\PawnIO'
```

## Notes for an Arrow Lake (PLAT_ARL) machine

The module's CPUID allowlist covers ARL (CPUID model 0xC5 / 0xC6) and ARL
is now in `is_platform_validated` alongside PTL. On a 285K-class machine
with a DDR5-7800 EXPO kit you should see:

* Static IOCTL (`ioctl_read_imc_clock`): `Source = MCHBAR_MEMSS_PMA`,
  `Flags = STATIC_LOCKED` (the `EXPERIMENTAL` bit is cleared because
  the value has been cross-checked four ways: module decode, HWiNFO64
  Memory Clock, SMBIOS `ConfiguredClockSpeed`, and the EXPO kit's
  nominal speed grade -- see `Deploy/VALIDATION-ARL.md` in the repo).
* Live IOCTL (`ioctl_read_imc_clock_live`): returns `STATUS_NOT_SUPPORTED`
  (HRESULT `0x80070032`). The live path **is** implemented for Core Ultra
  in `IntelIMC.p` via `SA_PERF_STATUS` at `MCHBAR+0x5918`, but on Arrow
  Lake-S that register reads as `0x00000000` even with SAGV actively
  transitioning the controller (verified on a 285K with HWiNFO Memory
  Clock observed swinging 2,400-3,900 MHz under load). The ADL/RPL/PTL
  layout does not survive into ARL-S, or the register is not populated
  by the SoC's power management at this offset, so the module
  short-circuits the live IOCTL on `PLAT_ARL` until a working live
  source is identified -- Intel PMT (the `IMC_SRC_PMT_QCLK_STATUS`
  enum already reserved in the module) is the most likely candidate.
  See `Deploy/VALIDATION-ARL.md` in the repo for the diagnostic capture.

Compute the consumer-visible numbers as `data_rate (MT/s) = QCLK * gear`
(equivalently `IO_clock (MHz) = QCLK * gear / 2`). On Gear2 hardware
(typical Arrow Lake) this is `QCLK * 2` for the data rate and `QCLK` for
the IO clock; do **not** copy the `QCLK * 2 * 2` shortcut from older
revisions of `Test-IntelIMC.ps1`, which was Gear4-only and overestimates
the data rate by 2x on ARL.

`MTL` and `LNL` remain `EXPERIMENTAL` until similar cross-validation lands
for those platforms. Extending the validated list follows the same
pattern: capture a HWiNFO64 sensor screenshot, confirm the four-way
agreement, add the platform tag to `is_platform_validated`, and rebuild.

## Uninstall

```powershell
.\Uninstall.ps1
Restart-Computer    # frees the loaded driver image; PawnIO has no DriverUnload
```

## Rebuilding from source

The `.amx` is signed with `my.key` (PKCS#8 RSA-2048 PEM) on the build host,
not bundled. Because the unrestricted driver accepts any signature, you do
*not* need that key on the target -- the pre-signed `IntelIMC.signed.amx`
loads as-is. Bring the key only if you want to sign a fresh `.amx` on the
target after editing `IntelIMC.p`.
