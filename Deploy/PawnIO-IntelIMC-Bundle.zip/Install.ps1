#requires -RunAsAdministrator
# Deploys the PawnIO unrestricted dev driver, test cert, and runtime onto a
# fresh machine. Idempotent: re-running upgrades the driver and refreshes
# the trust chain without duplicating service entries.
[CmdletBinding()]
param(
    [string]$DriverInstallDir  = 'C:\Program Files\PawnIO\driver',
    [string]$RuntimeInstallDir = 'C:\Program Files\PawnIO',
    [switch]$SkipReboot
)

$ErrorActionPreference = 'Stop'
$bundle = $PSScriptRoot

function Step($msg) { Write-Host "==> $msg" -ForegroundColor Cyan }

# 1. Testsigning must be on (kernel rejects self-signed drivers otherwise).
Step 'Checking Windows boot signing flags'
$ts = (bcdedit /enum '{current}' | Select-String -Pattern '^testsigning\s+(\w+)').Matches.Groups[1].Value
if ($ts -ne 'Yes') {
    Write-Warning 'testsigning is OFF. Run:  bcdedit /set testsigning on   then reboot, then re-run this installer.'
    if (-not $SkipReboot) { return }
} else {
    Write-Host '    testsigning = Yes'
}

# 2. Install the test signing cert into Root + TrustedPublisher so the
#    kernel accepts the driver's signature.
Step 'Importing PawnIO test cert into LocalMachine\Root and TrustedPublisher'
$cer = Join-Path $bundle 'driver\PawnIO_TestCert.cer'
Import-Certificate -FilePath $cer -CertStoreLocation Cert:\LocalMachine\Root            | Out-Null
Import-Certificate -FilePath $cer -CertStoreLocation Cert:\LocalMachine\TrustedPublisher | Out-Null
Write-Host '    cert installed'

# 3. Stage the driver in a stable directory under Program Files so the
#    service binPath does not depend on where the bundle is unpacked.
Step "Copying driver to $DriverInstallDir"
New-Item -ItemType Directory -Path $DriverInstallDir -Force | Out-Null
Copy-Item (Join-Path $bundle 'driver\PawnIO_unsigned.sys') $DriverInstallDir -Force
$sysPath = Join-Path $DriverInstallDir 'PawnIO_unsigned.sys'
Write-Host "    $sysPath"

# 4. Stage the usermode runtime.
Step "Copying runtime to $RuntimeInstallDir"
New-Item -ItemType Directory -Path $RuntimeInstallDir -Force | Out-Null
Copy-Item (Join-Path $bundle 'runtime\PawnIOLib.dll')  $RuntimeInstallDir -Force
Copy-Item (Join-Path $bundle 'runtime\PawnIOUtil.exe') $RuntimeInstallDir -Force
Write-Host '    PawnIOLib.dll, PawnIOUtil.exe staged'

# 5. Create or reconfigure the PawnIO kernel service. Stopping a running
#    PawnIO does not work (no DriverUnload), so when the service already
#    exists we just update binPath and warn that a reboot is needed.
Step 'Configuring PawnIO kernel service'
$existing = Get-CimInstance Win32_SystemDriver -Filter "Name='PawnIO'" -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "    service exists (state=$($existing.State)) - updating binPath"
    & sc.exe config PawnIO binPath= $sysPath | Out-Null
    if ($existing.State -eq 'Running') {
        Write-Warning 'PawnIO is already loaded. The new driver image will be used after the next reboot.'
    } else {
        Write-Host '    starting service'
        & sc.exe start PawnIO | Out-Null
    }
} else {
    Write-Host '    creating service'
    & sc.exe create PawnIO type= kernel start= demand error= normal binPath= $sysPath DisplayName= 'PawnIO Service' | Out-Null
    & sc.exe start PawnIO | Out-Null
}

# 6. Surface the active driver hash so the user can verify what is loaded.
Step 'Verifying'
$loaded = Get-CimInstance Win32_SystemDriver -Filter "Name='PawnIO'"
$hashLoaded = (Get-FileHash $sysPath -Algorithm SHA256).Hash
'    Service state : {0}' -f $loaded.State
'    PathName      : {0}' -f $loaded.PathName
'    On-disk hash  : {0}' -f $hashLoaded

Write-Host ''
Write-Host 'Done. To run a test:' -ForegroundColor Green
'  cd "{0}"'                                                            -f $bundle
'  & "{0}\PawnIOUtil.exe" test "{1}\IntelIMC.signed.amx"'                -f $RuntimeInstallDir, (Join-Path $bundle 'module')
'  .\test\Test-IntelIMC.ps1 -AmxPath "{0}\IntelIMC.signed.amx" -PawnIODir "{1}"' -f (Join-Path $bundle 'module'), $RuntimeInstallDir
