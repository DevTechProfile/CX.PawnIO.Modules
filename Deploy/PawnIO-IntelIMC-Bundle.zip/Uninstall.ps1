#requires -RunAsAdministrator
# Removes everything Install.ps1 added. Driver image is freed only after a
# reboot (PawnIO has no DriverUnload routine), so the .sys file may remain
# in the install dir until then.
[CmdletBinding()]
param(
    [string]$DriverInstallDir  = 'C:\Program Files\PawnIO\driver',
    [string]$RuntimeInstallDir = 'C:\Program Files\PawnIO'
)

$ErrorActionPreference = 'Continue'

Write-Host '==> Stopping and deleting PawnIO service'
& sc.exe stop   PawnIO 2>$null | Out-Null
& sc.exe delete PawnIO 2>$null | Out-Null

Write-Host '==> Removing test cert from Root and TrustedPublisher'
$thumbprint = '3E316A240E3EC644A820F949B3CB199FDDB2AA95'
foreach ($store in 'Cert:\LocalMachine\Root', 'Cert:\LocalMachine\TrustedPublisher') {
    $c = Get-ChildItem $store -ErrorAction SilentlyContinue | Where-Object Thumbprint -eq $thumbprint
    if ($c) { $c | Remove-Item }
}

Write-Host "==> Removing $RuntimeInstallDir and $DriverInstallDir"
Remove-Item $RuntimeInstallDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host 'Done. A reboot fully unloads the driver image from kernel memory.'
